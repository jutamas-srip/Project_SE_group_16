<?php 
class HistoryController
{	
	public function index()
	{	$HistoryList= History::getAll();
		require_once('views/history/index_history.php');
    }

	public function search()
	{
        $key=$_GET['key'];
        $HistoryList=History::search($key);
        require_once('views/history/index_history.php');
	}
	
	public function newHistory()
	{	
		$id=$_GET['EquipmentID'];
        $Equipment = Equipment::get($id);
        //$Eqtype = Eqtype::get($id);
        $EquipmentList=Equipment::getAll();
        $EqtypetList=Eqtype::getAll();
		require_once("views/History/newHistory.php");
	}

	public function addHistory()
	{

		$EquipmentName =$_GET['EquipmentName'];
		$EquipmentID=$_GET['EquipmentID'];
		$TypeID=$_GET['TypeID'];
        $Number = $_GET['Number'];
        $Fname = $_GET['Fname'];
        $Lname = $_GET['Lname'];
		$Project=$_GET['Project'];
        $Teacher=$_GET['Teacher'];
        $Reason=$_GET['Reason'];
        $DateBorrow=$_GET['DateBorrow'];
        $DateReturn=$_GET['DateReturn'];
        $Statuss=$_GET['Statuss'];
		History::Add($EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss);
		$HistoryList= History::getAll();
		require_once('views/history/index_history.php');
	
    }

    public function deleteConfirm()
	{
		$historyid=$_GET['historyid'];
		$History=History::get($historyid);
		require_once('views/History/deleteConfirm.php');
    }
    public function delete()
	{
			$historyid=$_GET['historyid'];
			History::delete($historyid);
			HistoryController::indexhis();
	}

	public function detailHistory()

	{	
		$id=$_GET['historyid'];
		$History = History::get($id);
		$HistoryList= History::getAll();
		require_once('views/History/detailHistory.php');
    }

	public function update()
	{
		$historyid =$_GET['historyid'];
        $EquipmentName =$_GET['EquipmentName'];
		$EquipmentID=$_GET['EquipmentID'];
		$TypeID=$_GET['TypeID'];
        $Number = $_GET['Number'];
        $Fname = $_GET['Fname'];
        $Lname = $_GET['Lname'];
		$Project=$_GET['Project'];
        $Teacher=$_GET['Teacher'];
        $Reason=$_GET['Reason'];
        $DateBorrow=$_GET['DateBorrow'];
        $DateReturn=$_GET['DateReturn'];
        $Statuss=$_GET['Statuss'];
		History::update($historyid,$EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss);
		HistoryController::index();
	}
    
}?>