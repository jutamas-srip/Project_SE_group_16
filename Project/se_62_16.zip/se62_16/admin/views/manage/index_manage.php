
<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</head>
    <style>

</style>
	
	<body>
		<div class="container">
			<div><br></div>
			
			<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Manage" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="Manage" class="form-control" placeholder="ค้นหา" aria-label="Manage" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2"><i class="fas fa-search"></i> Search</button>
						</div>
                                                <a href=?controller=Manage&action=newManage type='button' class='btn btn-primary'><i class="fas fa-folder-plus"></i> เพิ่มอุปกรณ์</a>
					</div>
				
				</form>
				<div class="mb-2">
                                                <a href=?key=&controller=Manage&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์ทั้งหมด</a>
						<a href=?key=Hardware&controller=Manage&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์ฮาร์ดแวร์</a>
						<a href=?key=Network&controller=Manage&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์เน็ตเวิร์ค</a>
						<a href=?key=Software&controller=Manage&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์ซอฟต์แวร์</a>
						
					</div>
		<table class="shadow table table-hover">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">ชื่ออุปกรณ์</th>
		        <th scope="col">เลขครุภัณฑ์</th>
			<th scope="col">หมวดหมู่</th>
			<th scope="col">จำนวน</th>
                        <th scope="col">สถานะ</th>
                        <th scope="col">ตัวจัดการ</th>

   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($ManageList as $Manage)
{
    echo"<tr align='center' > 

                 <td data-lable='ชื่ออุปกรณ์'>$Manage->EquipmentName</td>
                 <td data-lable='เลขครุภัณฑ์'>$Manage->EquipmentID</td>
                 <td data-lable='หมวดหมู่'>$Manage->TypeID</td>
                 <td data-lable='จำนวน'>$Manage->Quantity</td>
                 <td data-lable='สถานะ'>$Manage->EquipmentStatus</td>
                 <td><a href=?controller=Manage&action=updateForm&EquipmentID=$Manage->EquipmentID&TypeID=$Manage->TypeID class='badge badge-warning'><i class='fas fa-pen-square'></i> แก้ไข </a>
                 <a href=?controller=Manage&action=deleteConfirm&EquipmentID=$Manage->EquipmentID class='badge badge-danger'><i class='fas fa-folder-minus'></i> ลบ </a></td></tr>";
}
?>
				</tbody>
			</div>
	</body>

</html>


