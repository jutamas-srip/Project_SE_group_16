
<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</head>
    <style>

</style>
	
	<body>
		<div class="container">
			<div><br></div>
			
			<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="History" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="History" class="form-control" placeholder="ค้นหา" aria-label="History" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2"><i class="fas fa-search"></i> Search</button>
						</div>
					</div>
				
				</form>
				<div class="mb-2">
						<a href=?key=&controller=History&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> รายการยืมทั้งหมด</a>
						<a href=?key=รออนุมัติ&controller=History&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> รออนุมัติ</a>
						<a href=?key=อนุมัติแล้ว&controller=History&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อนุมัติแล้ว</a>
                        <a href=?key=ไม่อนุมัติ&controller=History&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> ไม่อนุมัติ</a>
						<a href=?key=ส่งคืนแล้ว&controller=History&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> ส่งคืนแล้ว</a>
						
					</div>
		<table class="shadow table table-hover">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">ลำดับ</th>
     			 <th scope="col">ชื่ออุปกรณ์</th>
				 <th scope="col">เลขครุภัณฑ์</th>
				 <th scope="col">หมวดหมู่</th>
				 <th scope="col">จำนวน</th>
				 <th scope="col">ชื่อ</th>
				 <th scope="col">นามสกุล</th>
				 <th scope="col">วันที่ยืม</th>
                 <th scope="col">วันที่คืน</th>
                 <th scope="col">สถานะ</th>
                 <th scope="col">ตัวจัดการ</th>

   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($HistoryList as $History)
{
    echo"<tr align='center' > 
	            <td data-lable='ลำดับ'>$History->historyid</td>
                 <td data-lable='ชื่ออุปกรณ์'>$History->EquipmentName</td>
                 <td data-lable='เลขครุภัณฑ์'>$History->EquipmentID</td>
                 <td data-lable='หมวดหมู่'>$History->TypeID</td>
                 <td data-lable='จำนวน'>$History->Number</td>
                 <td data-lable='ชื่อ'>$History->Fname</td>
                 <td data-lable='นามสกุล'>$History->Lname</td>
                 <td data-lable='วันที่ยืม'>$History->DateBorrow</td>
                 <td data-lable='วันที่คืน'>$History->DateReturn</td>
                 
                 ";

    if ($History->Statuss == "รออนุมัติ"){
        echo"
        <td data-lable='สถานะ' class='badge badge-pill badge-warning'><i class='fas fa-clock'></i> $History->Statuss</td>";
    }
    if ($History->Statuss == "อนุมัติแล้ว"){
        echo"
        <td data-lable='สถานะ' class='badge badge-pill badge-success'><i class='fas fa-check-circle'></i> $History->Statuss</td>";
    }
    if ($History->Statuss == "ไม่อนุมัติ"){
        echo"
        <td data-lable='สถานะ' class='badge badge-pill badge-danger'><i class='fas fa-times-circle'></i> $History->Statuss</td>";
    }
    if ($History->Statuss == "ส่งคืนแล้ว"){
        echo"
        <td data-lable='สถานะ' class='badge badge-pill badge-info'><i class='fas fa-calendar-check'></i> $History->Statuss</td>"; 
     }
     echo"
     <td><a href='?controller=History&action=detailHistory&historyid=$History->historyid' class='badge badge-pill badge-secondary'><i class='fas fa-folder-open'></i> รายละเอียด</a></td></tr>";

}
echo "</table>";
?>
				</tbody>
			</div>
	</body>

</html>




