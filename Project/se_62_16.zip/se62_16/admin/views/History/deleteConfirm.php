<?php echo "<br>Are you sure to delete this History <br>
            <br> $History->historyid $History->Fname $History->Lname <br>";?>
<form method="get" action="">
    <input type="hidden" name="controller" value="History"/>
    <input type="hidden" name="historyid" value="<?php echo $History->historyid; ?>" />
    <a href="?controller=History&action=indexhis" class="btn btn-outline-danger btn-lg btn-block" role="button">Back</a>
    <button type="submit" name="action" value="delete">Delete</button>
</form>