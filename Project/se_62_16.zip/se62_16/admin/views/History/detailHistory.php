
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>

<body>

    <div class="container">

        <div class="card shadow" style="width: 100%;
  max-width: 600px;
  padding: 15px;
  margin: auto;">
            <h5 class="card-header">รายละเอียดการยืม</h5>
            <div class="card-body">
                <div class="mb-3">
                <form method="get" action="">
                <input type="hidden" name="historyid"
   value= "<?php echo $History->historyid; ?>" />
                    <label>ชื่ออุปกรณ์ </label> <input type="text" name="EquipmentName" readonly ="true"
   value= "<?php echo $History->EquipmentName; ?>" class="form-control" required/>   
                </div>
                <div class="mb-3">
                    <label>เลขครุภัณฑ์ </label> <input type="text" name="EquipmentID" readonly ="true"
   value= "<?php echo $History->EquipmentID; ?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                    <label>หมวดหมู่ </label> <input type= "text" name="TypeID" readonly ="true"
    value= "<?php echo $History->TypeID; ?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                    <label>จำนวน </label> <input type="int" name="Number" readonly="true" 
value="1" class="form-control" required/>
                </div>
                <div class="row">
                    <div class="col-sm">
                        <label>ชื่อ </label> <input type="text" name="Fname" readonly ="true"
    value= "<?php echo $History->Fname; ?>"  class="form-control" required/>
                     </div>
                     <div class="col-sm">
                        <label>นามสกุล </label> <input type="text" name="Lname" readonly ="true"
    value= "<?php echo $History->Lname; ?>"  class="form-control" required/>
                    </div>
                </div>
                <div class="mb-3">
                    <label>ชื่อโครงการ </label> <input type="text" name="Project" readonly ="true"
    value= "<?php echo $History->Project; ?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                    <label>อาจารย์ผู้รับผิดชอบ </label> <input type="text" name="Teacher" readonly ="true"
    value= "<?php echo $History->Teacher; ?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                    <label>เหตุผลในการยืม-คืน </label> <input  type="text" name="Reason" readonly ="true"
    value= "<?php echo $History->Reason; ?>" class="form-control"  aria-label="With textarea" required >
                </div>
                <div class="row">
                    <div class="col-sm">
                        <label>กำหนดการยืม </label> <input type="Date" name="DateBorrow" readonly ="true"
    value= "<?php echo $History->DateBorrow; ?>"  class="form-control" required/>
                     </div>
                     <div class="col-sm">
                        <label> ถึง </label> <input type="Date" name="DateReturn" readonly ="true" value= "<?php echo $History->DateReturn; ?>"  class="form-control" required/>
                    </div>
                    <label><input type="hidden" name="Statuss" readonly="true" 
                                value="รออนุมัติ" /> </label><br>
                </div>   
                <div class="mb-3">
                <label>สถานะ</label><select name="Statuss" class="form-control" required>
    <?php echo "<option value='อนุมัติ'>อนุมัติแล้ว</option>";
          echo "<option value='ไม่อนุมัติ'>ไม่อนุมัติ</option>";
          echo "<option value='ส่งคืนแล้ว'>ส่งคืนแล้ว</option>";
    ?>
</select>
                </div>
                <div class="mb-4"></div>
				<div class="row">
                    <div class="col-sm">
                        <input type="hidden" name="controller" value="History" />
                    </div>
					<div class="col-sm">
                    <a href="?controller=History&action=index" class="btn btn-outline-danger btn-lg btn-block" role="button">ยกเลิก</a>
                    </div>

                    <div class="col-sm">
                        <button class="btn btn-outline-success btn-lg btn-block" type="submit" name="action" value="update"> บันทึก</button>
                    </div>
                </div>
</form>

            </div>
        </div>
    </div>
    </div>
    </div>

    <div>
        <br>
    </div>

</body>

</html>








