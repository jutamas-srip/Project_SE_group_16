<?php 
class History{
    public $historyid;
    public $EquipmentName;
    public $EquipmentID;
    public $TypeID;
    public $Number;
    public $Fname;
    public $Lname;
	public $Project;
	public $Teacher;
    public $Reason;
    public $DateBorrow;
    public $DateReturn;
    public $Statuss;

public function History($historyid,$EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss)
{
    $this->historyid = $historyid;
	$this->EquipmentName = $EquipmentName;
    $this->EquipmentID = $EquipmentID;
    $this->TypeID = $TypeID;
    $this->Number = $Number;
    $this->Fname = $Fname;
    $this->Lname = $Lname;
    $this->Project = $Project;
	$this->Teacher = $Teacher;
    $this->Reason = $Reason;
    $this->DateBorrow = $DateBorrow;
    $this->DateReturn = $DateReturn;
    $this->Statuss = $Statuss;
}


public static function get($id)
{
  require("connection_connect.php");
  $sql = "SELECT * from history  WHERE historyid='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $historyid=$my_row['historyid'];
  $EquipmentName=$my_row['EquipmentName'];
  $EquipmentID=$my_row['EquipmentID'];
  $TypeID=$my_row['TypeID'];
  $Number=$my_row['Number'];
  $Fname=$my_row['Fname'];
  $Lname=$my_row['Lname'];
  $Project=$my_row['Project'];
  $Teacher=$my_row['Teacher'];
  $Reason=$my_row['Reason'];
  $DateBorrow=$my_row['DateBorrow'];
  $DateReturn=$my_row['DateReturn'];
  $Statuss=$my_row['Statuss'];

  require("connection_close.php");

  return new History($historyid,$EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss);
}

public static function search($key)
{
	$HistoryList=[];
	require("connection_connect.php");
    $sql="select *from history 
    where (historyid like'%$key%' or EquipmentName like'%$key%' or EquipmentID  like'%$key%' or TypeID like'%$key%' or  Number like'%$key%' or Fname like'%$key%' or Lname like'%$key%' or DateBorrow like'%$key%' or DateReturn like'%$key%' or Statuss like'%$key%')";
    $result=$conn->query($sql);
    
	while($my_row=$result->fetch_assoc())
	{
     
        $historyid=$my_row['historyid'];
        $EquipmentName=$my_row['EquipmentName'];
        $EquipmentID=$my_row['EquipmentID'];
        $TypeID=$my_row['TypeID'];
        $Number=$my_row['Number'];
        $Fname=$my_row['Fname'];
        $Lname=$my_row['Lname'];
        $Project=$my_row['Project'];
        $Teacher=$my_row['Teacher'];
        $Reason=$my_row['Reason'];
        $DateBorrow=$my_row['DateBorrow'];
        $DateReturn=$my_row['DateReturn'];
        $Statuss=$my_row['Statuss'];
        
        $HistoryList[]=new History($historyid,$EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss);
	}
	require("connection_close.php");
	return $HistoryList;
}

public static function getAll()
{
    $HistoryList=[];
    require("connection_connect.php");
    $sql = "SELECT *FROM history";
    $result=$conn->query($sql);
    while($my_row = $result->fetch_assoc()){
    $historyid=$my_row['historyid'];    
    $EquipmentName=$my_row['EquipmentName'];    
    $EquipmentID=$my_row['EquipmentID'];
    $TypeID=$my_row['TypeID'];
    $Number=$my_row['Number'];
    $Fname=$my_row['Fname'];
    $Lname=$my_row['Lname'];
    $Project=$my_row['Project'];
    $Teacher=$my_row['Teacher'];
    $Reason=$my_row['Reason'];
    $DateBorrow=$my_row['DateBorrow'];
    $DateReturn=$my_row['DateReturn'];  
    $Statuss=$my_row['Statuss'];  
    $HistoryList[]= new History($historyid,$EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss);
}
require("connection_close.php");
return $HistoryList;
}

public static function Add($EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss)
{	require("connection_connect.php");
    $sql = "insert into History(EquipmentName,EquipmentID,TypeID,Number,Fname,Lname,Project,Teacher,Reason,DateBorrow,DateReturn,Statuss)
    values ('$EquipmentName','$EquipmentID','$TypeID','$Number','$Fname','$Lname','$Project','$Teacher','$Reason','$DateBorrow','$DateReturn','$Statuss')";
    $result=$conn->query($sql);
   
	require("connection_close.php");
    return "add success $result rows";
}
    
    public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from history	where historyid='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
    }
    public static function update($historyid,$EquipmentName,$EquipmentID,$TypeID,$Number,$Fname,$Lname,$Project,$Teacher,$Reason,$DateBorrow,$DateReturn,$Statuss)
{
	
	require("connection_connect.php");
	$sql="UPDATE history SET Statuss = '$Statuss'
     WHERE historyid = '$historyid'";
	$result=$conn->query($sql);

	require("connection_close.php");
	return "update success $result row";
}

}