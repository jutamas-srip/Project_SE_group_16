<?php
Class Eqtype{
public $TypeID; 
public $TypeName;


public function Eqtype($TypeID,$TypeName)
{
	
	$this->TypeID = $TypeID;
	$this->TypeName = $TypeName;

}
public static function getAll()
{
	$EqtypeList=[];
    require("connection_connect.php");
    $sql = "SELECT * FROM equipmenttype ";
	$result = $conn->query($sql);
	
    while($my_row=$result->fetch_assoc())
    	{
    		$TypeID=$my_row['TypeID'];
			$TypeName=$my_row['TypeName'];
			
      		$EqtypeList[] = new Eqtype($TypeID,$TypeName);
    	}
    	require("connection_close.php");
    	return $EqtypeList;
}  
public static function get($ID)
{
  require("connection_connect.php");
  $sql = "select * from equipmenttype where TypeID='$ID'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $TypeID=$my_row['TypeID'];
  $TypeName=$my_row['TypeName'];
 
  require("connection_close.php");

  return new Eqtype($TypeID,$TypeName);
}
public static function search($key)
{
	$EqtypeList=[];
	require("connection_connect.php");
    $sql="select *from equipmenttype where (TypeID like'%$key%' or TypeName like'%$key%')";
    $result=$conn->query($sql);
    
	while($my_row=$result->fetch_assoc())
	{
     
    $TypeID=$my_row['TypeID'];
    $TypeName=$my_row['TypeName'];
    
    $EqtypeList[]=new Eqtype($TypeID,$TypeName);
	}
	require("connection_close.php");
	return $EqtypeList;
}

        
}?>