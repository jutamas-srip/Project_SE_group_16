<?php
class EquipmentController
{
	public function index()
	{
		$EquipmentList = Equipment::getAll();
		require_once('views/equipment/index_equipment.php');
		$EqtypeList = Eqtype::getAll();

    }
    
	public function search()
	{
		$key=$_GET['key'];
		$EquipmentList=Equipment::search($key);
		require_once('views/equipment/index_equipment.php');
    }
}
?>