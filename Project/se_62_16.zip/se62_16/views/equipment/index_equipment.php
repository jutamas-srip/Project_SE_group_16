
<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</head>
    <style>

</style>
	
	<body>
		<div class="container">
			<div><br></div>
			
			<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Equipment" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="Equipment" class="form-control" placeholder="ค้นหา" aria-label="Equipment" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2"><i class="fas fa-search"></i> Search</button>
						</div>
					</div>
				
				</form>
				<div class="mb-2">
						<a href=?key=&controller=Equipment&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์ทั้งหมด</a>
						<a href=?key=Hardware&controller=Equipment&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์ฮาร์ดแวร์</a>
						<a href=?key=Network&controller=Equipment&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์เน็ตเวิร์ค</a>
						<a href=?key=Software&controller=Equipment&action=search type='button' class='btn btn-primary'><i class="fas fa-search-location"></i> อุปกรณ์ซอฟต์แวร์</a>
						
					</div>
		<table class="shadow table table-hover">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">เลขครุภัณฑ์</th>
     			 <th scope="col">ชื่ออุปกรณ์</th>
				 <th scope="col">รายละเอียด</th>
				 <th scope="col">สถานะ</th>
				 <th scope="col">หมวดหมู่</th>
				 <th scope="col">จำนวนที่มี</th>
				 <th scope="col">การยืม</th>
   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($EquipmentList as $Equipment)
{
    echo"<tr align='center' > 
	<td data-lable='เลขครุภัณฑ์'>$Equipment->EquipmentID</td>
    <td data-lable='ชื่ออุปกรณ์'>$Equipment->EquipmentName</td>
    <td data-lable='รายละเอียด'>$Equipment->EquipmentDetail</td>
    <td data-lable='สถานะ'>$Equipment->EquipmentStatus</td>	
    <td data-lable='หมวดหมู่'>$Equipment->TypeID</td>
    <td data-lable='จำนวนที่มี'>$Equipment->Quantity</td>
";

	if($Equipment->EquipmentStatus == "ไม่พร้อมใช้งาน" || $Equipment->EquipmentStatus == "หมด"){
		if($Equipment->Quantity == "0"){
			echo"
		<td data-lable='การยืม'><a href=?controller=History&action=newHistory&EquipmentID=$Equipment->EquipmentID&TypeID=$Equipment->TypeID class='btn btn-info btn disabled' role='button' aria-disabled='true' data-placement='right' title='กดยืมอุปกรณ์'><i class='fas fa-clipboard-check'></i> ยืมอุปกรณ์ </a></td></tr>";
		}
		if($Equipment->Quantity != "0"){
			echo"
		<td data-lable='การยืม'><a href=?controller=History&action=newHistory&EquipmentID=$Equipment->EquipmentID&TypeID=$Equipment->TypeID class='btn btn-info btn disabled' role='button' aria-disabled='true' data-placement='right' title='กดยืมอุปกรณ์'><i class='fas fa-clipboard-check'></i> ยืมอุปกรณ์ </a></td></tr>";
		}
	}
	if($Equipment->EquipmentStatus == "พร้อมใช้งาน"){
		if($Equipment->Quantity == "0"){
		echo"
		<td data-lable='การยืม'><a href=?controller=History&action=newHistory&EquipmentID=$Equipment->EquipmentID&TypeID=$Equipment->TypeID class='btn btn-info btn disabled' role='button' aria-disabled='true' data-placement='right' title='กดยืมอุปกรณ์'><i class='fas fa-clipboard-check'></i> ยืมอุปกรณ์ </a></td></tr>";
		}
		if($Equipment->Quantity != "0"){
			echo"
			<td data-lable='การยืม'><a href=?controller=History&action=newHistory&EquipmentID=$Equipment->EquipmentID&TypeID=$Equipment->TypeID class='btn btn-info ' role='button' aria-pressed='true' data-placement='right' title='กดยืมอุปกรณ์'><i class='fas fa-clipboard-check'></i> ยืมอุปกรณ์ </a></td></tr>";
			}
	}
}
echo "</table>";
?>
				</tbody>
			</div>
	</body>

</html>

